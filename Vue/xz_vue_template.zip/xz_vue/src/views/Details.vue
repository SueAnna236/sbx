<template>
    <div>
        <h3>This is an Details page</h3>
    </div>
</template>

<script>
    export default {
    }
</script>

<style scoped>

</style>